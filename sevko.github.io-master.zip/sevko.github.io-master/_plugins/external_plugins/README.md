# note
These plugin files were taken from elsewhere (see the header comments in each for source attribution), but couldn't be
included as submodules because I needed to make local changes and didn't want to maintain a fork of the original
projects.
