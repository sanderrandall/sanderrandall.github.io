# sevko.io
My personal portfolio site and blog, live at [sevko.io](https://sevko.io/); feel free to subscribe to my
[RSS feed](https://sevko.io/articles/feed.xml)! It's powered by Jekyll, Git LFS, S3, and CloudFront. The `Makefile`
contains useful directives for installing dependencies, building, and publishing.
